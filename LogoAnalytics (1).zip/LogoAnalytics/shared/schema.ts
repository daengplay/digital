import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const portfolioItems = pgTable("portfolio_items", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  imageUrl: text("image_url").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const contactSubmissions = pgTable("contact_submissions", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  service: text("service").notNull(),
  budget: text("budget"),
  description: text("description").notNull(),
  timeline: text("timeline"),
  status: text("status").default("new").notNull(), // new, contacted, in_progress, completed, cancelled
  notes: text("notes").default(""),
  followUpDate: timestamp("follow_up_date"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const logoAnalysis = pgTable("logo_analysis", {
  id: serial("id").primaryKey(),
  fileName: text("file_name").notNull(),
  filePath: text("file_path").notNull(),
  overallScore: integer("overall_score").notNull(),
  readability: integer("readability").notNull(),
  uniqueness: integer("uniqueness").notNull(),
  scalability: integer("scalability").notNull(),
  colorHarmony: integer("color_harmony").notNull(),
  typography: integer("typography").notNull(),
  balance: integer("balance").notNull(),
  memorability: integer("memorability").notNull(),
  versatility: integer("versatility").notNull(),
  brandAlignment: integer("brand_alignment").notNull(),
  technicalQuality: integer("technical_quality").notNull(),
  recommendations: text("recommendations").array().notNull(),
  colorAnalysis: text("color_analysis").notNull(),
  typographyAnalysis: text("typography_analysis").notNull(),
  shapeAnalysis: text("shape_analysis").notNull(),
  applicationAnalysis: text("application_analysis").notNull(),
  overallAssessment: text("overall_assessment").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertPortfolioItemSchema = createInsertSchema(portfolioItems).omit({
  id: true,
  createdAt: true,
});

export const insertContactSubmissionSchema = createInsertSchema(contactSubmissions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const updateContactSubmissionSchema = z.object({
  status: z.enum(["new", "contacted", "in_progress", "completed", "cancelled"]).optional(),
  notes: z.string().optional(),
  followUpDate: z.string().optional(), // Accept as string and convert in backend
});

export const changePasswordSchema = z.object({
  currentPassword: z.string().min(1, "Password saat ini harus diisi"),
  newPassword: z.string().min(6, "Password baru minimal 6 karakter"),
  confirmPassword: z.string().min(1, "Konfirmasi password harus diisi"),
}).refine((data) => data.newPassword === data.confirmPassword, {
  message: "Password baru dan konfirmasi password tidak cocok",
  path: ["confirmPassword"],
});

export const insertLogoAnalysisSchema = createInsertSchema(logoAnalysis).omit({
  id: true,
  createdAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type PortfolioItem = typeof portfolioItems.$inferSelect;
export type InsertPortfolioItem = z.infer<typeof insertPortfolioItemSchema>;
export type ContactSubmission = typeof contactSubmissions.$inferSelect;
export type InsertContactSubmission = z.infer<typeof insertContactSubmissionSchema>;
export type UpdateContactSubmission = z.infer<typeof updateContactSubmissionSchema>;
export type LogoAnalysis = typeof logoAnalysis.$inferSelect;
export type InsertLogoAnalysis = z.infer<typeof insertLogoAnalysisSchema>;
