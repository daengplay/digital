import { 
  users, 
  portfolioItems, 
  contactSubmissions, 
  logoAnalysis,
  type User, 
  type InsertUser,
  type PortfolioItem,
  type InsertPortfolioItem,
  type ContactSubmission,
  type InsertContactSubmission,
  type UpdateContactSubmission,
  type LogoAnalysis,
  type InsertLogoAnalysis
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  changePassword(userId: number, newPassword: string): Promise<boolean>;
  
  getPortfolioItems(): Promise<PortfolioItem[]>;
  getPortfolioItemsByCategory(category: string): Promise<PortfolioItem[]>;
  createPortfolioItem(item: InsertPortfolioItem): Promise<PortfolioItem>;
  updatePortfolioItem(id: number, item: InsertPortfolioItem): Promise<PortfolioItem | undefined>;
  deletePortfolioItem(id: number): Promise<boolean>;
  
  createContactSubmission(submission: InsertContactSubmission): Promise<ContactSubmission>;
  getAllContactSubmissions(): Promise<ContactSubmission[]>;
  updateContactSubmission(id: number, updates: Partial<{
    status: string;
    notes: string;
    followUpDate: Date;
  }>): Promise<ContactSubmission>;
  
  createLogoAnalysis(analysis: InsertLogoAnalysis): Promise<LogoAnalysis>;
  getLogoAnalysis(id: number): Promise<LogoAnalysis | undefined>;
  getAllLogoAnalyses(): Promise<LogoAnalysis[]>;
  deleteLogoAnalysis(id: number): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async changePassword(userId: number, newPassword: string): Promise<boolean> {
    const result = await db
      .update(users)
      .set({ password: newPassword })
      .where(eq(users.id, userId));
    return (result.rowCount || 0) > 0;
  }

  async getPortfolioItems(): Promise<PortfolioItem[]> {
    return await db.select().from(portfolioItems).orderBy(portfolioItems.createdAt);
  }

  async getPortfolioItemsByCategory(category: string): Promise<PortfolioItem[]> {
    return await db.select().from(portfolioItems).where(eq(portfolioItems.category, category)).orderBy(portfolioItems.createdAt);
  }

  async createPortfolioItem(insertItem: InsertPortfolioItem): Promise<PortfolioItem> {
    const [item] = await db
      .insert(portfolioItems)
      .values(insertItem)
      .returning();
    return item;
  }

  async updatePortfolioItem(id: number, updateItem: InsertPortfolioItem): Promise<PortfolioItem | undefined> {
    const [item] = await db
      .update(portfolioItems)
      .set(updateItem)
      .where(eq(portfolioItems.id, id))
      .returning();
    return item || undefined;
  }

  async deletePortfolioItem(id: number): Promise<boolean> {
    const result = await db
      .delete(portfolioItems)
      .where(eq(portfolioItems.id, id));
    return (result.rowCount || 0) > 0;
  }

  async createContactSubmission(insertSubmission: InsertContactSubmission): Promise<ContactSubmission> {
    const [submission] = await db
      .insert(contactSubmissions)
      .values({
        ...insertSubmission,
        phone: insertSubmission.phone || null,
        budget: insertSubmission.budget || null,
        timeline: insertSubmission.timeline || null,
      })
      .returning();
    return submission;
  }

  async createLogoAnalysis(insertAnalysis: InsertLogoAnalysis): Promise<LogoAnalysis> {
    const [analysis] = await db
      .insert(logoAnalysis)
      .values(insertAnalysis)
      .returning();
    return analysis;
  }

  async getLogoAnalysis(id: number): Promise<LogoAnalysis | undefined> {
    const [analysis] = await db.select().from(logoAnalysis).where(eq(logoAnalysis.id, id));
    return analysis || undefined;
  }

  async getAllContactSubmissions(): Promise<ContactSubmission[]> {
    return await db.select().from(contactSubmissions).orderBy(contactSubmissions.createdAt);
  }

  async getAllLogoAnalyses(): Promise<LogoAnalysis[]> {
    return await db.select().from(logoAnalysis).orderBy(logoAnalysis.createdAt);
  }

  async deleteLogoAnalysis(id: number): Promise<boolean> {
    const result = await db.delete(logoAnalysis).where(eq(logoAnalysis.id, id));
    return (result.rowCount || 0) > 0;
  }

  async updateContactSubmission(id: number, updates: Partial<{
    status: string;
    notes: string;
    followUpDate: Date;
  }>): Promise<ContactSubmission> {
    const [submission] = await db
      .update(contactSubmissions)
      .set({ 
        ...updates, 
        followUpDate: updates.followUpDate || null,
        updatedAt: new Date() 
      })
      .where(eq(contactSubmissions.id, id))
      .returning();
    return submission;
  }
}

export const storage = new DatabaseStorage();
