import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContactSubmissionSchema, insertLogoAnalysisSchema, updateContactSubmissionSchema, insertPortfolioItemSchema, changePasswordSchema } from "@shared/schema";
import { analyzeLogoWithAI } from "./ai-logo-analysis";
import multer from "multer";
import path from "path";
import { existsSync } from "fs";
import "./types"; // Import session type declarations

const upload = multer({
  dest: 'uploads/',
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    console.log('File filter - original name:', file.originalname);
    console.log('File filter - mimetype:', file.mimetype);
    
    const allowedTypes = /jpeg|jpg|png|svg/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype) || file.mimetype.includes('image/');

    if (mimetype && extname) {
      console.log('File accepted');
      return cb(null, true);
    } else {
      console.log('File rejected');
      cb(new Error('Only image files (JPEG, PNG, SVG) are allowed'));
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Get portfolio items
  app.get("/api/portfolio", async (req, res) => {
    try {
      const category = req.query.category as string;
      const items = category && category !== 'all' 
        ? await storage.getPortfolioItemsByCategory(category)
        : await storage.getPortfolioItems();
      res.json(items);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch portfolio items" });
    }
  });

  // Admin portfolio management routes
  app.post("/api/admin/portfolio", async (req, res) => {
    try {
      // Check if user is admin
      if (!req.session.user || !req.session.user.isAdmin) {
        return res.status(401).json({ error: "Unauthorized" });
      }

      const validatedData = insertPortfolioItemSchema.parse(req.body);
      const portfolioItem = await storage.createPortfolioItem(validatedData);
      res.json(portfolioItem);
    } catch (error) {
      console.error("Portfolio creation error:", error);
      res.status(400).json({ error: "Failed to create portfolio item" });
    }
  });

  app.put("/api/admin/portfolio/:id", async (req, res) => {
    try {
      // Check if user is admin
      if (!req.session.user || !req.session.user.isAdmin) {
        return res.status(401).json({ error: "Unauthorized" });
      }

      const id = parseInt(req.params.id);
      const validatedData = insertPortfolioItemSchema.parse(req.body);
      const portfolioItem = await storage.updatePortfolioItem(id, validatedData);
      
      if (!portfolioItem) {
        return res.status(404).json({ error: "Portfolio item not found" });
      }
      
      res.json(portfolioItem);
    } catch (error) {
      console.error("Portfolio update error:", error);
      res.status(400).json({ error: "Failed to update portfolio item" });
    }
  });

  app.delete("/api/admin/portfolio/:id", async (req, res) => {
    try {
      // Check if user is admin
      if (!req.session.user || !req.session.user.isAdmin) {
        return res.status(401).json({ error: "Unauthorized" });
      }

      const id = parseInt(req.params.id);
      const success = await storage.deletePortfolioItem(id);
      
      if (!success) {
        return res.status(404).json({ error: "Portfolio item not found" });
      }
      
      res.json({ success: true });
    } catch (error) {
      console.error("Portfolio deletion error:", error);
      res.status(500).json({ error: "Failed to delete portfolio item" });
    }
  });

  // Submit contact form
  app.post("/api/contact", async (req, res) => {
    try {
      const validatedData = insertContactSubmissionSchema.parse(req.body);
      const submission = await storage.createContactSubmission(validatedData);
      
      // In a real app, you would send an email here
      console.log("New contact submission:", submission);
      
      res.json({ success: true, id: submission.id });
    } catch (error) {
      console.error("Contact form error:", error);
      res.status(400).json({ error: "Invalid form data" });
    }
  });

  // Upload and analyze logo
  app.post("/api/analyze-logo", upload.single('logo'), async (req, res) => {
    try {
      console.log('File upload request received');
      console.log('Request file:', req.file);
      console.log('Request body:', req.body);
      
      if (!req.file) {
        console.log('No file found in request');
        return res.status(400).json({ error: "No file uploaded" });
      }

      // AI-powered logo analysis
      console.log('Analyzing logo with AI...');
      const aiAnalysis = await analyzeLogoWithAI(req.file.path, req.file.originalname);
      
      const analysisData = {
        fileName: aiAnalysis.fileName,
        filePath: req.file.path,
        overallScore: aiAnalysis.overallScore,
        readability: aiAnalysis.readability,
        uniqueness: aiAnalysis.uniqueness,
        scalability: aiAnalysis.scalability,
        colorHarmony: aiAnalysis.colorHarmony,
        typography: aiAnalysis.typography,
        balance: aiAnalysis.balance,
        memorability: aiAnalysis.memorability,
        versatility: aiAnalysis.versatility,
        brandAlignment: aiAnalysis.brandAlignment,
        technicalQuality: aiAnalysis.technicalQuality,
        recommendations: aiAnalysis.recommendations,
        colorAnalysis: aiAnalysis.detailedAnalysis.colorAnalysis,
        typographyAnalysis: aiAnalysis.detailedAnalysis.typographyAnalysis,
        shapeAnalysis: aiAnalysis.detailedAnalysis.shapeAnalysis,
        applicationAnalysis: aiAnalysis.detailedAnalysis.applicationAnalysis,
        overallAssessment: aiAnalysis.detailedAnalysis.overallAssessment
      };

      const analysis = await storage.createLogoAnalysis(analysisData);
      res.json(analysis);
    } catch (error) {
      console.error("Logo analysis error:", error);
      res.status(500).json({ error: "Failed to analyze logo" });
    }
  });

  // Get logo analysis result
  app.get("/api/analyze-logo/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const analysis = await storage.getLogoAnalysis(id);
      
      if (!analysis) {
        return res.status(404).json({ error: "Analysis not found" });
      }
      
      res.json(analysis);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch analysis" });
    }
  });



  // Serve uploaded files
  app.get("/api/uploads/:filename", (req, res) => {
    try {
      const filename = req.params.filename;
      const filePath = path.join(process.cwd(), 'uploads', filename);
      res.sendFile(filePath);
    } catch (error) {
      res.status(500).json({ error: "Failed to serve file" });
    }
  });

  // Admin authentication
  app.post("/api/admin/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      // Simple hardcoded credentials for demo
      if (username === "admin" && password === "lagoku123") {
        const adminUser = {
          id: 1,
          username: "admin",
          isAdmin: true
        };
        
        // In a real app, you would set session or JWT here
        req.session.user = adminUser;
        res.json(adminUser);
      } else {
        res.status(401).json({ error: "Username atau password salah" });
      }
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ error: "Login gagal" });
    }
  });

  app.post("/api/admin/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        console.error("Logout error:", err);
        res.status(500).json({ error: "Logout gagal" });
      } else {
        res.sendStatus(200);
      }
    });
  });

  app.get("/api/admin/user", (req, res) => {
    if (req.session.user) {
      res.json(req.session.user);
    } else {
      res.sendStatus(401);
    }
  });

  // Middleware untuk proteksi admin routes
  const requireAdmin = (req: any, res: any, next: any) => {
    if (req.session.user && req.session.user.isAdmin) {
      next();
    } else {
      res.status(401).json({ error: "Unauthorized - Admin access required" });
    }
  };

  // Protected admin endpoints
  app.get("/api/admin/contacts", requireAdmin, async (req, res) => {
    try {
      const contacts = await storage.getAllContactSubmissions();
      res.json(contacts);
    } catch (error) {
      console.error("Failed to fetch contacts:", error);
      res.status(500).json({ error: "Failed to fetch contacts" });
    }
  });

  app.get("/api/admin/analyses", requireAdmin, async (req, res) => {
    try {
      const analyses = await storage.getAllLogoAnalyses();
      res.json(analyses);
    } catch (error) {
      console.error("Failed to fetch analyses:", error);
      res.status(500).json({ error: "Failed to fetch analyses" });
    }
  });

  // Delete logo analysis
  app.delete("/api/admin/analyses/:id", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteLogoAnalysis(id);
      
      if (!success) {
        return res.status(404).json({ error: "Analysis not found" });
      }
      
      res.json({ success: true });
    } catch (error) {
      console.error("Logo analysis deletion error:", error);
      res.status(500).json({ error: "Failed to delete analysis" });
    }
  });

  // Change admin password
  app.patch("/api/admin/change-password", requireAdmin, async (req, res) => {
    try {
      const { currentPassword, newPassword } = changePasswordSchema.parse(req.body);
      const userId = req.session.user?.id;
      
      if (!userId) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      
      // Verify current password
      const user = await storage.getUser(userId);
      if (!user || user.password !== currentPassword) {
        return res.status(400).json({ error: "Password saat ini tidak benar" });
      }
      
      // Update password
      const success = await storage.changePassword(userId, newPassword);
      if (!success) {
        return res.status(500).json({ error: "Gagal mengubah password" });
      }
      
      res.json({ success: true, message: "Password berhasil diubah" });
    } catch (error) {
      console.error("Change password error:", error);
      res.status(500).json({ error: "Gagal mengubah password" });
    }
  });

  // Update contact submission for follow up
  app.patch("/api/admin/contacts/:id", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const rawData = updateContactSubmissionSchema.parse(req.body);
      
      // Prepare update data with proper type conversion
      const updateData: any = {};
      if (rawData.status) updateData.status = rawData.status;
      if (rawData.notes !== undefined) updateData.notes = rawData.notes;
      if (rawData.followUpDate) updateData.followUpDate = new Date(rawData.followUpDate);
      
      const updatedSubmission = await storage.updateContactSubmission(id, updateData);
      res.json(updatedSubmission);
    } catch (error) {
      console.error("Failed to update contact submission:", error);
      res.status(500).json({ error: "Failed to update contact submission" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
