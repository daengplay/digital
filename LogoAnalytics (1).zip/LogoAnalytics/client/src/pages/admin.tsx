import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { 
  BarChart3, 
  Users, 
  Image, 
  MessageSquare, 
  Search,
  Calendar,
  Download,
  Eye,
  Edit,
  Trash2,
  LogOut,
  Phone,
  Mail,
  Clock,
  FileText,
  Database,
  Plus,
  Lightbulb,
  ArrowRight
} from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import ContactFollowUpModal from "@/components/contact-follow-up-modal";
import ContactDetailModal from "@/components/contact-detail-modal";
import PortfolioFormModal from "@/components/portfolio-form-modal";
import ChangePasswordModal from "@/components/change-password-modal";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { PortfolioItem, ContactSubmission, LogoAnalysis } from "@shared/schema";

export default function AdminPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const { user, logoutMutation } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch data for dashboard
  const { data: portfolioItems = [] } = useQuery<PortfolioItem[]>({
    queryKey: ['/api/portfolio'],
  });

  const { data: contactSubmissions = [] } = useQuery<ContactSubmission[]>({
    queryKey: ['/api/admin/contacts'],
  });

  const { data: logoAnalyses = [] } = useQuery<LogoAnalysis[]>({
    queryKey: ['/api/admin/analyses'],
  });

  // Delete logo analysis mutation
  const deleteAnalysisMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest("DELETE", `/api/admin/analyses/${id}`);
      if (!response.ok) {
        throw new Error("Failed to delete analysis");
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/analyses"] });
      toast({
        title: "Berhasil!",
        description: "Analisa logo telah dihapus.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Dashboard stats
  const stats = [
    {
      title: "Total Portfolio",
      value: portfolioItems.length,
      icon: Image,
      color: "bg-blue-500"
    },
    {
      title: "Kontak Masuk",
      value: contactSubmissions.length,
      icon: MessageSquare,
      color: "bg-green-500"
    },
    {
      title: "Analisa Logo",
      value: logoAnalyses.length,
      icon: BarChart3,
      color: "bg-purple-500"
    },
    {
      title: "Klien Aktif",
      value: contactSubmissions.filter(c => c.service).length,
      icon: Users,
      color: "bg-orange-500"
    }
  ];

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('id-ID', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "new": return "bg-blue-100 text-blue-800";
      case "contacted": return "bg-yellow-100 text-yellow-800";
      case "in_progress": return "bg-purple-100 text-purple-800";
      case "completed": return "bg-green-100 text-green-800";
      case "cancelled": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "new": return "Baru";
      case "contacted": return "Sudah Dihubungi";
      case "in_progress": return "Sedang Proses";
      case "completed": return "Selesai";
      case "cancelled": return "Dibatalkan";
      default: return status || "Baru";
    }
  };

  // Export functions
  const exportContactsToCSV = () => {
    const headers = [
      'ID',
      'Nama',
      'Email', 
      'Telefon',
      'Layanan',
      'Budget',
      'Deskripsi',
      'Timeline',
      'Status',
      'Catatan',
      'Follow Up Date',
      'Tanggal Dibuat',
      'Tanggal Update'
    ];

    const csvData = contactSubmissions.map(contact => [
      contact.id,
      contact.name,
      contact.email,
      contact.phone || '',
      contact.service,
      contact.budget || '',
      contact.description.replace(/"/g, '""'), // Escape quotes in description
      contact.timeline || '',
      getStatusLabel(contact.status || "new"),
      contact.notes?.replace(/"/g, '""') || '',
      contact.followUpDate ? formatDate(contact.followUpDate) : '',
      formatDate(contact.createdAt),
      formatDate(contact.updatedAt)
    ]);

    const csvContent = [headers, ...csvData]
      .map(row => row.map(field => `"${field}"`).join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `kontak-submissions-${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const exportContactsToJSON = () => {
    const exportData = {
      exportDate: new Date().toISOString(),
      totalRecords: contactSubmissions.length,
      data: contactSubmissions.map(contact => ({
        ...contact,
        statusLabel: getStatusLabel(contact.status || "new")
      }))
    };

    const jsonContent = JSON.stringify(exportData, null, 2);
    const blob = new Blob([jsonContent], { type: 'application/json;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `kontak-data-${new Date().toISOString().split('T')[0]}.json`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const exportAnalysesToCSV = () => {
    const headers = [
      'ID',
      'Nama File',
      'Overall Score',
      'Readability',
      'Uniqueness', 
      'Scalability',
      'Color Harmony',
      'Typography',
      'Balance',
      'Memorability',
      'Versatility',
      'Brand Alignment',
      'Technical Quality',
      'Tanggal Analisa'
    ];

    const csvData = logoAnalyses.map(analysis => [
      analysis.id,
      analysis.fileName,
      analysis.overallScore,
      analysis.readability,
      analysis.uniqueness,
      analysis.scalability,
      analysis.colorHarmony,
      analysis.typography,
      analysis.balance,
      analysis.memorability,
      analysis.versatility,
      analysis.brandAlignment,
      analysis.technicalQuality,
      formatDate(analysis.createdAt)
    ]);

    const csvContent = [headers, ...csvData]
      .map(row => row.map(field => `"${field}"`).join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `logo-analyses-${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const exportAnalysesToJSON = () => {
    const exportData = {
      exportDate: new Date().toISOString(),
      totalRecords: logoAnalyses.length,
      data: logoAnalyses
    };

    const jsonContent = JSON.stringify(exportData, null, 2);
    const blob = new Blob([jsonContent], { type: 'application/json;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `logo-analyses-data-${new Date().toISOString().split('T')[0]}.json`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const exportSingleAnalysis = (analysis: LogoAnalysis) => {
    const detailedData = {
      id: analysis.id,
      fileName: analysis.fileName,
      createdAt: analysis.createdAt,
      scores: {
        overallScore: analysis.overallScore,
        readability: analysis.readability,
        uniqueness: analysis.uniqueness,
        scalability: analysis.scalability,
        colorHarmony: analysis.colorHarmony,
        typography: analysis.typography,
        balance: analysis.balance,
        memorability: analysis.memorability,
        versatility: analysis.versatility,
        brandAlignment: analysis.brandAlignment,
        technicalQuality: analysis.technicalQuality
      },
      recommendations: analysis.recommendations,
      detailedAnalysis: {
        colorAnalysis: analysis.colorAnalysis,
        typographyAnalysis: analysis.typographyAnalysis,
        shapeAnalysis: analysis.shapeAnalysis,
        applicationAnalysis: analysis.applicationAnalysis,
        overallAssessment: analysis.overallAssessment
      }
    };

    const jsonContent = JSON.stringify(detailedData, null, 2);
    const blob = new Blob([jsonContent], { type: 'application/json;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `analisa-${analysis.fileName}-${analysis.id}.json`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Delete portfolio item mutation
  const deletePortfolioMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("DELETE", `/api/admin/portfolio/${id}`);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/portfolio"] });
      toast({
        title: "Portfolio berhasil dihapus",
        description: "Item portfolio telah dihapus dari database",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Gagal menghapus portfolio",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleDeletePortfolio = (id: number, title: string) => {
    if (window.confirm(`Apakah Anda yakin ingin menghapus portfolio "${title}"? Aksi ini tidak bisa dibatalkan.`)) {
      deletePortfolioMutation.mutate(id);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-primary">Lagoku Admin</h1>
              <div className="ml-4 text-sm text-gray-600">
                Selamat datang, {user?.username}
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Cari..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-64"
                />
              </div>

              <Button 
                variant="outline" 
                onClick={() => logoutMutation.mutate()}
                disabled={logoutMutation.isPending}
              >
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Dashboard Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                    <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
                  </div>
                  <div className={`w-12 h-12 ${stat.color} rounded-lg flex items-center justify-center`}>
                    <stat.icon className="text-white w-6 h-6" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="contacts" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="contacts">Kontak Masuk</TabsTrigger>
            <TabsTrigger value="portfolio">Portfolio</TabsTrigger>
            <TabsTrigger value="analyses">Analisa Logo</TabsTrigger>
            <TabsTrigger value="settings">Pengaturan</TabsTrigger>
          </TabsList>

          {/* Contact Submissions */}
          <TabsContent value="contacts">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Kontak Submission</span>
                  <div className="flex space-x-2">
                    <Button onClick={exportContactsToCSV} variant="outline">
                      <FileText className="w-4 h-4 mr-2" />
                      Export CSV
                    </Button>
                    <Button onClick={exportContactsToJSON} variant="outline">
                      <Database className="w-4 h-4 mr-2" />
                      Export Data
                    </Button>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {contactSubmissions.length === 0 ? (
                    <p className="text-center text-gray-500 py-8">Belum ada kontak masuk</p>
                  ) : (
                    contactSubmissions.map((contact) => (
                      <div key={contact.id} className="border rounded-lg p-4 hover:bg-gray-50">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center space-x-3 mb-2">
                              <h3 className="font-semibold text-gray-900">{contact.name}</h3>
                              <Badge variant="outline">{contact.service}</Badge>
                              {contact.budget && (
                                <Badge variant="secondary">{contact.budget}</Badge>
                              )}
                              <Badge className={getStatusColor(contact.status || "new")}>
                                {getStatusLabel(contact.status || "new")}
                              </Badge>
                            </div>
                            
                            <div className="flex items-center space-x-4 mb-2 text-sm text-gray-600">
                              <div className="flex items-center space-x-1">
                                <Mail className="w-4 h-4" />
                                <span>{contact.email}</span>
                              </div>
                              {contact.phone && (
                                <div className="flex items-center space-x-1">
                                  <Phone className="w-4 h-4" />
                                  <span>{contact.phone}</span>
                                </div>
                              )}
                            </div>
                            
                            <p className="text-gray-700 mb-2">{contact.description}</p>
                            
                            {contact.notes && (
                              <div className="bg-yellow-50 border-l-4 border-yellow-400 p-2 mb-2">
                                <p className="text-sm text-yellow-800">
                                  <strong>Catatan:</strong> {contact.notes}
                                </p>
                              </div>
                            )}
                            
                            <div className="flex items-center justify-between text-xs text-gray-500">
                              <span>
                                Dibuat: {formatDate(contact.createdAt)}
                                {contact.timeline && ` • Timeline: ${contact.timeline}`}
                              </span>
                              {contact.followUpDate && (
                                <div className="flex items-center space-x-1">
                                  <Clock className="w-3 h-3" />
                                  <span>Follow-up: {formatDate(contact.followUpDate)}</span>
                                </div>
                              )}
                            </div>
                          </div>
                          
                          <div className="flex flex-col space-y-2">
                            <ContactFollowUpModal contact={contact}>
                              <Button size="sm" variant="outline">
                                <MessageSquare className="w-4 h-4 mr-2" />
                                Follow Up
                              </Button>
                            </ContactFollowUpModal>
                            <ContactDetailModal contact={contact}>
                              <Button size="sm" variant="outline">
                                <Eye className="w-4 h-4 mr-2" />
                                Detail
                              </Button>
                            </ContactDetailModal>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Portfolio Management */}
          <TabsContent value="portfolio">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Manajemen Portfolio</span>
                  <PortfolioFormModal mode="add">
                    <Button>
                      <Plus className="w-4 h-4 mr-2" />
                      Tambah Portfolio
                    </Button>
                  </PortfolioFormModal>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {portfolioItems.map((item) => (
                    <div key={item.id} className="border rounded-lg overflow-hidden hover:shadow-md transition-shadow">
                      <img 
                        src={item.imageUrl} 
                        alt={item.title}
                        className="w-full h-48 object-cover"
                      />
                      <div className="p-4">
                        <h3 className="font-semibold text-gray-900 mb-2">{item.title}</h3>
                        <p className="text-sm text-gray-600 mb-3">{item.description}</p>
                        <div className="flex items-center justify-between">
                          <Badge variant="outline">{item.category}</Badge>
                          <div className="flex space-x-2">
                            <PortfolioFormModal mode="edit" portfolioItem={item}>
                              <Button size="sm" variant="outline">
                                <Edit className="w-4 h-4" />
                              </Button>
                            </PortfolioFormModal>
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => handleDeletePortfolio(item.id, item.title)}
                              disabled={deletePortfolioMutation.isPending}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Logo Analyses */}
          <TabsContent value="analyses">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Analisa Logo</span>
                  <div className="flex space-x-2">
                    <Button onClick={exportAnalysesToCSV} variant="outline">
                      <FileText className="w-4 h-4 mr-2" />
                      Export CSV
                    </Button>
                    <Button onClick={exportAnalysesToJSON} variant="outline">
                      <Database className="w-4 h-4 mr-2" />
                      Export Data
                    </Button>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {logoAnalyses.length === 0 ? (
                    <p className="text-center text-gray-500 py-8">Belum ada analisa logo</p>
                  ) : (
                    logoAnalyses.map((analysis) => (
                      <div key={analysis.id} className="border rounded-lg p-4 hover:bg-gray-50">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h3 className="font-semibold text-gray-900 mb-2">{analysis.fileName}</h3>
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-3">
                              <div className="text-center">
                                <p className="text-2xl font-bold text-primary">{analysis.overallScore}</p>
                                <p className="text-xs text-gray-500">Overall Score</p>
                              </div>
                              <div className="text-center">
                                <p className="text-lg font-semibold text-blue-600">{analysis.readability}</p>
                                <p className="text-xs text-gray-500">Readability</p>
                              </div>
                              <div className="text-center">
                                <p className="text-lg font-semibold text-green-600">{analysis.uniqueness}</p>
                                <p className="text-xs text-gray-500">Uniqueness</p>
                              </div>
                              <div className="text-center">
                                <p className="text-lg font-semibold text-purple-600">{analysis.scalability}</p>
                                <p className="text-xs text-gray-500">Scalability</p>
                              </div>
                            </div>
                            <p className="text-xs text-gray-500">
                              {formatDate(analysis.createdAt)}
                            </p>
                          </div>
                          <div className="flex space-x-2">
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button size="sm" variant="outline">
                                  <Eye className="w-4 h-4" />
                                </Button>
                              </DialogTrigger>
                              <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                                <DialogHeader>
                                  <DialogTitle>Detail Analisa Logo</DialogTitle>
                                  <DialogDescription>
                                    Hasil lengkap analisa untuk {analysis.fileName}
                                  </DialogDescription>
                                </DialogHeader>
                                
                                <div className="space-y-6">
                                  {/* Logo Image */}
                                  {analysis.filePath && (
                                    <div className="flex justify-center mb-6">
                                      <div className="bg-white p-4 rounded-2xl shadow-lg">
                                        <img 
                                          src={`/api/uploads/${analysis.filePath.split('/').pop()}`}
                                          alt={analysis.fileName}
                                          className="max-w-sm max-h-64 object-contain"
                                          onError={(e) => {
                                            (e.target as HTMLImageElement).style.display = 'none';
                                          }}
                                        />
                                      </div>
                                    </div>
                                  )}

                                  {/* Overall Score */}
                                  <div className="bg-gradient-to-r from-green-400 to-blue-500 rounded-2xl p-6 text-white">
                                    <div className="flex items-center justify-between">
                                      <div>
                                        <h4 className="text-lg font-semibold">Skor Keseluruhan</h4>
                                        <p className="text-green-100">Logo memiliki kualitas yang baik</p>
                                      </div>
                                      <div className="text-right">
                                        <div className="text-4xl font-bold">{analysis.overallScore}</div>
                                        <div className="text-green-100">dari 100</div>
                                      </div>
                                    </div>
                                  </div>

                                  {/* Detailed Scores Grid */}
                                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    {[
                                      { label: "Readability", value: analysis.readability, color: "bg-green-500" },
                                      { label: "Uniqueness", value: analysis.uniqueness, color: "bg-blue-500" },
                                      { label: "Scalability", value: analysis.scalability, color: "bg-purple-500" },
                                      { label: "Color Harmony", value: analysis.colorHarmony, color: "bg-orange-500" },
                                      { label: "Typography", value: analysis.typography, color: "bg-indigo-500" },
                                      { label: "Balance", value: analysis.balance, color: "bg-teal-500" },
                                      { label: "Memorability", value: analysis.memorability, color: "bg-pink-500" },
                                      { label: "Versatility", value: analysis.versatility, color: "bg-yellow-500" },
                                      { label: "Brand Alignment", value: analysis.brandAlignment, color: "bg-red-500" },
                                      { label: "Technical Quality", value: analysis.technicalQuality, color: "bg-gray-500" },
                                    ].map((score, index) => (
                                      <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                                        <span className="font-medium">{score.label}</span>
                                        <div className="flex items-center">
                                          <Progress value={score.value} className="w-24 mr-3" />
                                          <span className={`font-bold text-lg ${score.color.replace('bg-', 'text-')}`}>
                                            {score.value}
                                          </span>
                                        </div>
                                      </div>
                                    ))}
                                  </div>

                                  {/* Detailed Analysis Sections */}
                                  {(analysis as any).colorAnalysis && (
                                    <div className="bg-gradient-to-r from-orange-50 to-red-50 border border-orange-200 rounded-2xl p-6">
                                      <h4 className="text-xl font-bold text-dark mb-4 flex items-center">
                                        <div className="w-6 h-6 bg-orange-500 rounded-full mr-3"></div>
                                        Analisa Warna
                                      </h4>
                                      <p className="text-gray-700 leading-relaxed">
                                        {(analysis as any).colorAnalysis}
                                      </p>
                                    </div>
                                  )}

                                  {(analysis as any).typographyAnalysis && (
                                    <div className="bg-gradient-to-r from-purple-50 to-indigo-50 border border-purple-200 rounded-2xl p-6">
                                      <h4 className="text-xl font-bold text-dark mb-4 flex items-center">
                                        <div className="w-6 h-6 bg-purple-500 rounded-full mr-3"></div>
                                        Analisa Tipografi
                                      </h4>
                                      <p className="text-gray-700 leading-relaxed">
                                        {(analysis as any).typographyAnalysis}
                                      </p>
                                    </div>
                                  )}

                                  {(analysis as any).shapeAnalysis && (
                                    <div className="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-2xl p-6">
                                      <h4 className="text-xl font-bold text-dark mb-4 flex items-center">
                                        <div className="w-6 h-6 bg-green-500 rounded-full mr-3"></div>
                                        Analisa Bentuk & Komposisi
                                      </h4>
                                      <p className="text-gray-700 leading-relaxed">
                                        {(analysis as any).shapeAnalysis}
                                      </p>
                                    </div>
                                  )}

                                  {(analysis as any).applicationAnalysis && (
                                    <div className="bg-gradient-to-r from-blue-50 to-cyan-50 border border-blue-200 rounded-2xl p-6">
                                      <h4 className="text-xl font-bold text-dark mb-4 flex items-center">
                                        <div className="w-6 h-6 bg-blue-500 rounded-full mr-3"></div>
                                        Analisa Pengaplikasian
                                      </h4>
                                      <p className="text-gray-700 leading-relaxed">
                                        {(analysis as any).applicationAnalysis}
                                      </p>
                                    </div>
                                  )}

                                  {(analysis as any).overallAssessment && (
                                    <div className="bg-gradient-to-r from-gray-50 to-slate-50 border border-gray-200 rounded-2xl p-6">
                                      <h4 className="text-xl font-bold text-dark mb-4 flex items-center">
                                        <div className="w-6 h-6 bg-gray-500 rounded-full mr-3"></div>
                                        Penilaian Keseluruhan
                                      </h4>
                                      <p className="text-gray-700 leading-relaxed">
                                        {(analysis as any).overallAssessment}
                                      </p>
                                    </div>
                                  )}

                                  {/* Recommendations */}
                                  {analysis.recommendations && analysis.recommendations.length > 0 && (
                                    <div className="bg-yellow-50 border border-yellow-200 rounded-2xl p-6">
                                      <h4 className="text-xl font-bold text-dark mb-4 flex items-center">
                                        <Lightbulb className="text-yellow-500 w-6 h-6 mr-3" />
                                        Rekomendasi Perbaikan
                                      </h4>
                                      <ul className="space-y-3 text-gray-700">
                                        {analysis.recommendations.map((recommendation, index) => (
                                          <li key={index} className="flex items-start">
                                            <ArrowRight className="text-primary w-5 h-5 mr-3 mt-0.5 flex-shrink-0" />
                                            <span>{recommendation}</span>
                                          </li>
                                        ))}
                                      </ul>
                                    </div>
                                  )}
                                </div>
                              </DialogContent>
                            </Dialog>
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => exportSingleAnalysis(analysis)}
                            >
                              <Download className="w-4 h-4" />
                            </Button>
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => {
                                if (confirm(`Apakah Anda yakin ingin menghapus analisa "${analysis.fileName}"?`)) {
                                  deleteAnalysisMutation.mutate(analysis.id);
                                }
                              }}
                              disabled={deleteAnalysisMutation.isPending}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Settings */}
          <TabsContent value="settings">
            <Card>
              <CardHeader>
                <CardTitle>Pengaturan Website</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-semibold mb-4">Konfigurasi AI</h3>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          OpenAI API Status
                        </label>
                        <div className="flex items-center space-x-2">
                          <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                          <span className="text-sm text-gray-600">API Key Error - Perlu diperbaiki</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold mb-4">Database</h3>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between p-4 border rounded-lg">
                        <div>
                          <p className="font-medium">PostgreSQL Database</p>
                          <p className="text-sm text-gray-600">Status koneksi database</p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                          <span className="text-sm text-gray-600">Connected</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold mb-4">Keamanan</h3>
                    <div className="space-y-2">
                      <ChangePasswordModal>
                        <Button variant="outline" className="w-full justify-start">
                          🔒 Ganti Password Admin
                        </Button>
                      </ChangePasswordModal>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold mb-4">Backup & Maintenance</h3>
                    <div className="space-y-2">
                      <Button variant="outline" className="w-full justify-start">
                        <Download className="w-4 h-4 mr-2" />
                        Download Database Backup
                      </Button>
                      <Button variant="outline" className="w-full justify-start">
                        <BarChart3 className="w-4 h-4 mr-2" />
                        Generate Analytics Report
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}