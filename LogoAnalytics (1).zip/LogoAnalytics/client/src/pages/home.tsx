import Navigation from "@/components/navigation";
import HeroSection from "@/components/hero-section";
import ServicesSection from "@/components/services-section";
import LogoAnalysisTool from "@/components/logo-analysis-tool";
import PortfolioGallery from "@/components/portfolio-gallery";
import TestimonialsSection from "@/components/testimonials-section";
import ProcessSection from "@/components/process-section";
import ContactSection from "@/components/contact-section";
import Footer from "@/components/footer";

export default function Home() {
  return (
    <div className="min-h-screen">
      <Navigation />
      <HeroSection />
      <ServicesSection />
      <LogoAnalysisTool />
      <PortfolioGallery />
      <TestimonialsSection />
      <ProcessSection />
      <ContactSection />
      <Footer />
    </div>
  );
}
