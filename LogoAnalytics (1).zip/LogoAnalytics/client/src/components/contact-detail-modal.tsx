import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { format } from "date-fns";
import { 
  Eye, 
  Mail, 
  MessageCircle, 
  Clock, 
  User, 
  DollarSign, 
  Calendar,
  FileText,
  Target,
  Phone
} from "lucide-react";
import type { ContactSubmission } from "@shared/schema";

interface ContactDetailModalProps {
  contact: ContactSubmission;
  children: React.ReactNode;
}

export default function ContactDetailModal({ contact, children }: ContactDetailModalProps) {
  const [open, setOpen] = useState(false);

  const getStatusColor = (status: string) => {
    switch (status) {
      case "new": return "bg-blue-100 text-blue-800";
      case "contacted": return "bg-yellow-100 text-yellow-800";
      case "in_progress": return "bg-purple-100 text-purple-800";
      case "completed": return "bg-green-100 text-green-800";
      case "cancelled": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "new": return "Baru";
      case "contacted": return "Sudah Dihubungi";
      case "in_progress": return "Sedang Proses";
      case "completed": return "Selesai";
      case "cancelled": return "Dibatalkan";
      default: return status || "Baru";
    }
  };

  const getServiceLabel = (service: string) => {
    switch (service) {
      case "logo": return "Desain Logo";
      case "brand": return "Brand Guidelines";
      case "trademark": return "Pendaftaran Merek";
      default: return service;
    }
  };

  const getBudgetLabel = (budget: string) => {
    switch (budget) {
      case "500k-1m": return "Rp 500.000 - Rp 1.000.000";
      case "1m-2m": return "Rp 1.000.000 - Rp 2.000.000";
      case "2m-5m": return "Rp 2.000.000 - Rp 5.000.000";
      case "5m+": return "Rp 5.000.000+";
      default: return budget;
    }
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('id-ID', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px] max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Eye className="w-5 h-5" />
            Detail Kontak - {contact.name}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Status Badge */}
          <div className="flex justify-center">
            <Badge className={`${getStatusColor(contact.status || "new")} text-sm px-4 py-2`}>
              {getStatusLabel(contact.status || "new")}
            </Badge>
          </div>

          <Separator />

          {/* Contact Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <User className="w-5 h-5" />
              Informasi Kontak
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4 text-gray-500" />
                  <div>
                    <p className="text-sm text-gray-500">Nama</p>
                    <p className="font-medium">{contact.name}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-gray-500" />
                  <div>
                    <p className="text-sm text-gray-500">Email</p>
                    <p className="font-medium">{contact.email}</p>
                  </div>
                </div>

                {contact.phone && (
                  <div className="flex items-center gap-2">
                    <Phone className="w-4 h-4 text-gray-500" />
                    <div>
                      <p className="text-sm text-gray-500">Telepon</p>
                      <p className="font-medium">{contact.phone}</p>
                    </div>
                  </div>
                )}
              </div>

              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Target className="w-4 h-4 text-gray-500" />
                  <div>
                    <p className="text-sm text-gray-500">Layanan</p>
                    <p className="font-medium">{getServiceLabel(contact.service)}</p>
                  </div>
                </div>

                {contact.budget && (
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-gray-500" />
                    <div>
                      <p className="text-sm text-gray-500">Budget</p>
                      <p className="font-medium">{getBudgetLabel(contact.budget)}</p>
                    </div>
                  </div>
                )}

                {contact.timeline && (
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-gray-500" />
                    <div>
                      <p className="text-sm text-gray-500">Timeline</p>
                      <p className="font-medium">{contact.timeline}</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          <Separator />

          {/* Project Description */}
          <div className="space-y-3">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Deskripsi Proyek
            </h3>
            <div className="bg-gray-50 p-4 rounded-lg">
              <p className="text-gray-700 whitespace-pre-wrap">{contact.description}</p>
            </div>
          </div>

          {/* Notes */}
          {contact.notes && (
            <>
              <Separator />
              <div className="space-y-3">
                <h3 className="text-lg font-semibold">Catatan Follow-up</h3>
                <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded-r-lg">
                  <p className="text-yellow-800 whitespace-pre-wrap">{contact.notes}</p>
                </div>
              </div>
            </>
          )}

          {/* Timeline Information */}
          <Separator />
          <div className="space-y-3">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              Timeline
            </h3>
            
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-500">Kontak masuk:</span>
                <span className="text-sm font-medium">{formatDate(contact.createdAt)}</span>
              </div>
              
              {contact.updatedAt && contact.updatedAt !== contact.createdAt && (
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-500">Terakhir diupdate:</span>
                  <span className="text-sm font-medium">{formatDate(contact.updatedAt)}</span>
                </div>
              )}
              
              {contact.followUpDate && (
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-500">Follow-up berikutnya:</span>
                  <span className="text-sm font-medium text-blue-600">
                    {formatDate(contact.followUpDate)}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-2 pt-4">
            <Button 
              variant="outline" 
              onClick={() => {
                const subject = `Lagoku - Follow up ${getServiceLabel(contact.service)}`;
                const body = `Halo ${contact.name},\n\nTerima kasih telah menghubungi Lagoku untuk kebutuhan ${getServiceLabel(contact.service)} Anda.\n\nSaya ingin menindaklanjuti permintaan Anda terkait:\n${contact.description}\n\nMohon kabari kami jika ada pertanyaan atau informasi tambahan yang diperlukan.\n\nSalam,\nTeam Lagoku`;
                window.open(`mailto:${contact.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`);
              }}
              className="flex-1"
            >
              <Mail className="w-4 h-4 mr-2" />
              Kirim Email
            </Button>
            {contact.phone && (
              <Button 
                variant="outline" 
                onClick={() => {
                  // Clean phone number for WhatsApp (remove spaces, dashes, etc)
                  const cleanPhone = contact.phone!.replace(/[^\d+]/g, '');
                  // Convert Indonesian phone format
                  const whatsappPhone = cleanPhone.startsWith('0') 
                    ? '62' + cleanPhone.substring(1) 
                    : cleanPhone.startsWith('+62') 
                    ? cleanPhone.substring(1)
                    : cleanPhone.startsWith('62')
                    ? cleanPhone
                    : '62' + cleanPhone;
                  
                  const message = `Halo ${contact.name}, saya dari Lagoku ingin menindaklanjuti permintaan ${getServiceLabel(contact.service)} Anda. Apakah ada waktu untuk diskusi lebih lanjut?`;
                  window.open(`https://wa.me/${whatsappPhone}?text=${encodeURIComponent(message)}`);
                }}
                className="flex-1"
              >
                <MessageCircle className="w-4 h-4 mr-2" />
                WhatsApp
              </Button>
            )}
            <Button 
              variant="outline" 
              onClick={() => setOpen(false)}
              className="flex-1"
            >
              Tutup
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}