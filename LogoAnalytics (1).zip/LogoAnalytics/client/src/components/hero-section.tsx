import { Button } from "@/components/ui/button";
import { Palette, Search, Tag, Play } from "lucide-react";

export default function HeroSection() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section
      id="home"
      className="pt-16 min-h-screen flex items-center hero-gradient"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="text-white fade-in">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              Wujudkan Brand Impian Anda dengan{" "}
              <span className="text-yellow-300">Logo Profesional</span>
            </h1>
            <p className="text-xl mb-8 text-gray-200 leading-relaxed">
              Lagoku hadir sebagai solusi lengkap untuk kebutuhan desain logo,
              analisa kualitas, dan pendaftaran merek dagang Anda. Dipercaya
              oleh 500+ klien di seluruh Indonesia.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                onClick={() => scrollToSection("contact")}
                className="bg-white text-primary px-8 py-4 h-auto rounded-xl font-semibold hover:bg-gray-100 transition-colors hover-lift"
              >
                Mulai Konsultasi
              </Button>
              <Button
                onClick={() => scrollToSection("portfolio")}
                variant=""
                className="bg-white text-primary px-8 py-4 h-auto rounded-xl font-semibold hover:bg-gray-100 transition-colors hover-lift"
              >
                <Play className="w-4 h-4 mr-2" />
                Lihat Portfolio
              </Button>
            </div>
          </div>

          <div className="relative fade-in">
            <div className="bg-white/10 backdrop-blur-md rounded-3xl p-8 glass-effect">
              <div className="space-y-6">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-yellow-400 rounded-full flex items-center justify-center">
                    <Palette className="text-white w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-white font-semibold">
                      Desain Profesional
                    </h3>
                    <p className="text-gray-200 text-sm">
                      Brand guidelines lengkap
                    </p>
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-green-400 rounded-full flex items-center justify-center">
                    <Search className="text-white w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-white font-semibold">
                      Analisa Logo AI
                    </h3>
                    <p className="text-gray-200 text-sm">
                      Scoring otomatis & saran
                    </p>
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-blue-400 rounded-full flex items-center justify-center">
                    <Tag className="text-white w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-white font-semibold">Daftar Merek</h3>
                    <p className="text-gray-200 text-sm">
                      Bantuan legal trademark
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
