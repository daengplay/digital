import { Card, CardContent } from "@/components/ui/card";
import { Lightbulb, PencilRuler, Palette, RotateCcw, Check } from "lucide-react";

const processSteps = [
  {
    number: 1,
    title: "Konsultasi & Brief",
    description: "Kami mulai dengan memahami visi, misi, dan target audience brand Anda. Sesi konsultasi mendalam untuk menggali insight yang akan menjadi foundation desain.",
    features: [
      "Brand discovery session",
      "Competitor analysis",
      "Creative brief finalisasi"
    ],
    icon: Lightbulb,
    gradient: "from-blue-50 to-indigo-50",
    border: "border-blue-200",
    iconBg: "bg-primary"
  },
  {
    number: 2,
    title: "Riset & Konsep",
    description: "Tim kreatif kami melakukan riset mendalam tentang industri, tren desain, dan preferensi target market untuk menghasilkan konsep yang tepat sasaran.",
    features: [
      "Market research",
      "Mood board creation",
      "Concept sketching"
    ],
    icon: PencilRuler,
    gradient: "from-purple-50 to-pink-50",
    border: "border-purple-200",
    iconBg: "bg-secondary"
  },
  {
    number: 3,
    title: "Desain & Presentasi",
    description: "Eksekusi konsep menjadi desain visual yang powerful. Kami presentasikan 3-5 alternatif desain dengan penjelasan rasional di balik setiap pilihan.",
    features: [
      "Multiple design options",
      "Design rationale",
      "Application mockups"
    ],
    icon: Palette,
    gradient: "from-green-50 to-emerald-50",
    border: "border-green-200",
    iconBg: "bg-green-500"
  },
  {
    number: 4,
    title: "Revisi & Refinement",
    description: "Berdasarkan feedback Anda, kami melakukan fine-tuning untuk mencapai hasil yang sempurna. Proses revisi dilakukan hingga Anda 100% puas.",
    features: [
      "Unlimited revisions",
      "Detail refinements",
      "Color & typography tuning"
    ],
    icon: RotateCcw,
    gradient: "from-orange-50 to-red-50",
    border: "border-orange-200",
    iconBg: "bg-orange-500"
  },
  {
    number: 5,
    title: "Finalisasi & Delivery",
    description: "Penyerahan file final dalam berbagai format, brand guidelines lengkap, dan jika diperlukan, bantuan implementasi untuk berbagai media aplikasi.",
    features: [
      "Multiple file formats",
      "Brand guidelines",
      "Implementation support"
    ],
    icon: Check,
    gradient: "from-indigo-50 to-purple-50",
    border: "border-indigo-200",
    iconBg: "bg-indigo-500"
  }
];

export default function ProcessSection() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-dark mb-6">Proses Kerja Kami</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Metodologi yang terstruktur dan transparan untuk memastikan hasil terbaik bagi setiap klien
          </p>
        </div>

        <div className="relative">
          {/* Process Timeline for Desktop */}
          <div className="hidden lg:block absolute left-1/2 transform -translate-x-1/2 h-full w-1 bg-gradient-to-b from-primary to-secondary"></div>
          
          <div className="space-y-12">
            {processSteps.map((step, index) => (
              <div key={index} className="relative flex items-center">
                {/* Left side for odd steps, right side for even steps */}
                <div className={`lg:w-1/2 ${index % 2 === 0 ? 'lg:pr-12 lg:text-right' : 'lg:pl-12 lg:order-2'}`}>
                  <Card className={`bg-gradient-to-br ${step.gradient} p-8 ${step.border}`}>
                    <CardContent className="p-0">
                      <h3 className="text-2xl font-bold text-dark mb-4">{step.number}. {step.title}</h3>
                      <p className="text-gray-600 leading-relaxed mb-6">
                        {step.description}
                      </p>
                      <ul className="space-y-2 text-gray-600">
                        {step.features.map((feature, featureIndex) => (
                          <li key={featureIndex} className="flex items-center">
                            <Check className="text-green-500 w-4 h-4 mr-3" />
                            {feature}
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </div>

                {/* Center icon for desktop */}
                <div className="hidden lg:flex absolute left-1/2 transform -translate-x-1/2 w-16 h-16 bg-white rounded-full items-center justify-center border-4 border-white shadow-lg">
                  <div className={`w-12 h-12 ${step.iconBg} rounded-full flex items-center justify-center`}>
                    <step.icon className="text-white w-6 h-6" />
                  </div>
                </div>

                {/* Mobile icon */}
                <div className="lg:hidden w-12 h-12 bg-primary rounded-full flex items-center justify-center mr-4">
                  <step.icon className="text-white w-6 h-6" />
                </div>

                {/* Spacer for even steps on desktop */}
                <div className={`lg:w-1/2 ${index % 2 === 1 ? 'lg:pr-12' : ''}`}></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
