import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { PortfolioItem } from "@shared/schema";

const portfolioFormSchema = z.object({
  title: z.string().min(1, "Judul harus diisi"),
  description: z.string().min(1, "Deskripsi harus diisi"),
  category: z.string().min(1, "Kategori harus dipilih"),
  imageUrl: z.string().url("URL gambar harus valid"),
});

type PortfolioFormData = z.infer<typeof portfolioFormSchema>;

interface PortfolioFormModalProps {
  children: React.ReactNode;
  portfolioItem?: PortfolioItem;
  mode: "add" | "edit";
}

export default function PortfolioFormModal({ 
  children, 
  portfolioItem, 
  mode 
}: PortfolioFormModalProps) {
  const [open, setOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<PortfolioFormData>({
    resolver: zodResolver(portfolioFormSchema),
    defaultValues: {
      title: portfolioItem?.title || "",
      description: portfolioItem?.description || "",
      category: portfolioItem?.category || "",
      imageUrl: portfolioItem?.imageUrl || "",
    },
  });

  const mutation = useMutation({
    mutationFn: async (data: PortfolioFormData) => {
      if (mode === "edit" && portfolioItem) {
        const res = await apiRequest("PUT", `/api/admin/portfolio/${portfolioItem.id}`, data);
        return await res.json();
      } else {
        const res = await apiRequest("POST", "/api/admin/portfolio", data);
        return await res.json();
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/portfolio"] });
      toast({
        title: mode === "add" ? "Portfolio berhasil ditambahkan" : "Portfolio berhasil diperbarui",
        description: "Data portfolio telah disimpan",
      });
      setOpen(false);
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: mode === "add" ? "Gagal menambahkan portfolio" : "Gagal memperbarui portfolio",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: PortfolioFormData) => {
    mutation.mutate(data);
  };

  const categories = [
    { value: "logo-design", label: "Logo Design" },
    { value: "brand-identity", label: "Brand Identity" },
    { value: "web-design", label: "Web Design" },
    { value: "print-design", label: "Print Design" },
    { value: "packaging", label: "Packaging" },
    { value: "illustration", label: "Illustration" },
  ];

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>
            {mode === "add" ? "Tambah Portfolio Baru" : "Edit Portfolio"}
          </DialogTitle>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Judul Project</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      placeholder="Masukkan judul project"
                      disabled={mutation.isPending}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Deskripsi</FormLabel>
                  <FormControl>
                    <Textarea
                      {...field}
                      placeholder="Masukkan deskripsi project"
                      rows={4}
                      disabled={mutation.isPending}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="category"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Kategori</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger disabled={mutation.isPending}>
                        <SelectValue placeholder="Pilih kategori" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category.value} value={category.value}>
                          {category.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="imageUrl"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>URL Gambar</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      type="url"
                      placeholder="https://example.com/image.jpg"
                      disabled={mutation.isPending}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex justify-end space-x-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => setOpen(false)}
                disabled={mutation.isPending}
              >
                Batal
              </Button>
              <Button type="submit" disabled={mutation.isPending}>
                {mutation.isPending 
                  ? (mode === "add" ? "Menambahkan..." : "Memperbarui...") 
                  : (mode === "add" ? "Tambah Portfolio" : "Perbarui Portfolio")
                }
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}