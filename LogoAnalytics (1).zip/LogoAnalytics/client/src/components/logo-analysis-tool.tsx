import { useState, useRef } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { CloudUpload, Lightbulb, ArrowRight } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { LogoAnalysis } from "@shared/schema";

export default function LogoAnalysisTool() {
  const [analysis, setAnalysis] = useState<LogoAnalysis | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const analyzeLogoMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("logo", file);
      const response = await apiRequest("POST", "/api/analyze-logo", formData);
      return response.json();
    },
    onSuccess: (data: LogoAnalysis) => {
      setAnalysis(data);
      toast({
        title: "Analisa Selesai!",
        description:
          "Logo Anda telah berhasil dianalisa. Lihat hasilnya di bawah.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Gagal menganalisa logo. Silakan coba lagi.",
        variant: "destructive",
      });
      console.error("Analysis error:", error);
    },
  });

  const handleFileUpload = (file: File) => {
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File Terlalu Besar",
        description: "Ukuran file maksimal 5MB",
        variant: "destructive",
      });
      return;
    }

    const allowedTypes = [
      "image/jpeg",
      "image/jpg",
      "image/png",
      "image/svg+xml",
    ];
    if (!allowedTypes.includes(file.type)) {
      toast({
        title: "Format File Tidak Didukung",
        description: "Silakan upload file PNG, JPG, atau SVG",
        variant: "destructive",
      });
      return;
    }

    analyzeLogoMutation.mutate(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFileUpload(files[0]);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      handleFileUpload(files[0]);
    }
  };

  const openFileDialog = () => {
    fileInputRef.current?.click();
  };

  const scoreDetails = analysis
    ? [
        {
          label: "Readability",
          value: analysis.readability,
          color: "bg-green-500",
        },
        {
          label: "Uniqueness",
          value: analysis.uniqueness,
          color: "bg-blue-500",
        },
        {
          label: "Scalability",
          value: analysis.scalability,
          color: "bg-purple-500",
        },
        {
          label: "Color Harmony",
          value: analysis.colorHarmony,
          color: "bg-orange-500",
        },
        {
          label: "Typography",
          value: analysis.typography,
          color: "bg-indigo-500",
        },
        { label: "Balance", value: analysis.balance, color: "bg-teal-500" },
        {
          label: "Memorability",
          value: analysis.memorability,
          color: "bg-pink-500",
        },
        {
          label: "Versatility",
          value: analysis.versatility,
          color: "bg-yellow-500",
        },
        {
          label: "Brand Alignment",
          value: analysis.brandAlignment,
          color: "bg-red-500",
        },
        {
          label: "Technical Quality",
          value: analysis.technicalQuality,
          color: "bg-gray-500",
        },
      ]
    : [];

  return (
    <section
      id="analysis"
      className="py-20 bg-gradient-to-br from-gray-50 to-blue-50"
    >
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-dark mb-6">
            Analisa Logo Gratis
          </h2>
          <p className="text-xl text-gray-600">
            Upload logo Anda dan dapatkan evaluasi instan dari AI kami untuk 10
            aspek penting desain logo
          </p>
        </div>

        <Card className="rounded-3xl shadow-2xl">
          <CardContent className="p-8">
            {/* Upload Area */}
            <div
              className={`upload-area rounded-2xl p-12 text-center mb-8 cursor-pointer ${
                isDragOver ? "drag-over" : ""
              }`}
              onDrop={handleDrop}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onClick={openFileDialog}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileSelect}
                className="hidden"
              />
              <div className="mb-6">
                <CloudUpload className="mx-auto text-primary mb-4 w-16 h-16" />
                <h3 className="text-2xl font-semibold text-dark mb-2">
                  Upload Logo Anda
                </h3>
                <p className="text-gray-600">
                  Seret & lepas file atau klik untuk browse
                </p>
                <p className="text-sm text-gray-500 mt-2">
                  Format: PNG, JPG, SVG (Max: 5MB)
                </p>
              </div>
              <Button
                className="bg-primary text-white px-8 py-3 rounded-xl font-semibold hover:bg-blue-700 transition-colors"
                disabled={analyzeLogoMutation.isPending}
              >
                {analyzeLogoMutation.isPending
                  ? "Menganalisa..."
                  : "Pilih File"}
              </Button>
            </div>

            {/* Analysis Results */}
            {analysis && (
              <div className="space-y-8">
                <h3 className="text-2xl font-bold text-dark mb-6">
                  Hasil Analisa Logo
                </h3>

                {/* Overall Score */}
                <div className="bg-gradient-to-r from-green-400 to-blue-500 rounded-2xl p-6 text-white">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-lg font-semibold">
                        Skor Keseluruhan
                      </h4>
                      <p className="text-green-100">
                        Logo Anda memiliki kualitas yang baik
                      </p>
                    </div>
                    <div className="text-right">
                      <div className="text-4xl font-bold">
                        {analysis.overallScore}
                      </div>
                      <div className="text-green-100">dari 100</div>
                    </div>
                  </div>
                </div>

                {/* Detailed Scores */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {scoreDetails.map((score, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between p-4 bg-gray-50 rounded-xl"
                    >
                      <span className="font-medium">{score.label}</span>
                      <div className="flex items-center">
                        <Progress value={score.value} className="w-24 mr-3" />
                        <span
                          className={`font-bold text-lg ${score.color.replace("bg-", "text-")}`}
                        >
                          {score.value}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Detailed Analysis Sections */}
                <div className="space-y-6">
                  {/* Color Analysis */}
                  <div className="bg-gradient-to-r from-orange-50 to-red-50 border border-orange-200 rounded-2xl p-6">
                    <h4 className="text-xl font-bold text-dark mb-4 flex items-center">
                      <div className="w-6 h-6 bg-orange-500 rounded-full mr-3"></div>
                      Analisa Warna
                    </h4>
                    <p className="text-gray-700 leading-relaxed">
                      {(analysis as any).colorAnalysis ||
                        "Analisa warna sedang diproses..."}
                    </p>
                  </div>

                  {/* Typography Analysis */}
                  <div className="bg-gradient-to-r from-purple-50 to-indigo-50 border border-purple-200 rounded-2xl p-6">
                    <h4 className="text-xl font-bold text-dark mb-4 flex items-center">
                      <div className="w-6 h-6 bg-purple-500 rounded-full mr-3"></div>
                      Analisa Tipografi
                    </h4>
                    <p className="text-gray-700 leading-relaxed">
                      {(analysis as any).typographyAnalysis ||
                        "Analisa tipografi sedang diproses..."}
                    </p>
                  </div>

                  {/* Shape Analysis */}
                  <div className="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-2xl p-6">
                    <h4 className="text-xl font-bold text-dark mb-4 flex items-center">
                      <div className="w-6 h-6 bg-green-500 rounded-full mr-3"></div>
                      Analisa Bentuk & Komposisi
                    </h4>
                    <p className="text-gray-700 leading-relaxed">
                      {(analysis as any).shapeAnalysis ||
                        "Analisa bentuk sedang diproses..."}
                    </p>
                  </div>

                  {/* Application Analysis */}
                  <div className="bg-gradient-to-r from-blue-50 to-cyan-50 border border-blue-200 rounded-2xl p-6">
                    <h4 className="text-xl font-bold text-dark mb-4 flex items-center">
                      <div className="w-6 h-6 bg-blue-500 rounded-full mr-3"></div>
                      Analisa Pengaplikasian
                    </h4>
                    <p className="text-gray-700 leading-relaxed">
                      {(analysis as any).applicationAnalysis ||
                        "Analisa pengaplikasian sedang diproses..."}
                    </p>
                  </div>

                  {/* Overall Assessment */}
                  <div className="bg-gradient-to-r from-gray-50 to-slate-50 border border-gray-200 rounded-2xl p-6">
                    <h4 className="text-xl font-bold text-dark mb-4 flex items-center">
                      <div className="w-6 h-6 bg-gray-500 rounded-full mr-3"></div>
                      Penilaian Keseluruhan
                    </h4>
                    <p className="text-gray-700 leading-relaxed">
                      {(analysis as any).overallAssessment ||
                        "Penilaian keseluruhan sedang diproses..."}
                    </p>
                  </div>
                </div>

                {/* Recommendations */}
                <div className="bg-yellow-50 border border-yellow-200 rounded-2xl p-6">
                  <h4 className="text-xl font-bold text-dark mb-4 flex items-center">
                    <Lightbulb className="text-yellow-500 w-6 h-6 mr-3" />
                    Rekomendasi Perbaikan
                  </h4>
                  <ul className="space-y-3 text-gray-700">
                    {analysis.recommendations.map((recommendation, index) => (
                      <li key={index} className="flex items-start">
                        <ArrowRight className="text-primary w-5 h-5 mr-3 mt-0.5 flex-shrink-0" />
                        <span>{recommendation}</span>
                      </li>
                    ))}
                  </ul>

                  <div className="mt-6 pt-6 border-t border-yellow-200">
                    <p className="text-sm text-gray-600 mb-4">
                      Konsultasikan Segera Logo Anda
                    </p>
                    <Button
                      className="bg-primary text-white px-6 py-3 rounded-xl font-semibold hover:opacity-90 transition-opacity"
                      onClick={() => {
                        const url = new URL(window.location.href);
                        url.searchParams.set("service", "expert-consultation");
                        url.hash = "#contact";
                        window.location.href = url.toString();
                      }}
                    >
                      Klik Untuk Mulai Konsultasi
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
