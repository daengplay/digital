import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { format } from "date-fns";
import { CalendarIcon, MessageSquare } from "lucide-react";
import type { ContactSubmission } from "@shared/schema";

const followUpSchema = z.object({
  status: z.enum(["new", "contacted", "in_progress", "completed", "cancelled"]),
  notes: z.string().optional(),
  followUpDate: z.date().optional(),
});

type FollowUpData = z.infer<typeof followUpSchema>;

interface ContactFollowUpModalProps {
  contact: ContactSubmission;
  children: React.ReactNode;
}

export default function ContactFollowUpModal({ contact, children }: ContactFollowUpModalProps) {
  const [open, setOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<FollowUpData>({
    resolver: zodResolver(followUpSchema),
    defaultValues: {
      status: contact.status as any || "new",
      notes: contact.notes || "",
      followUpDate: contact.followUpDate ? new Date(contact.followUpDate) : undefined,
    },
  });

  const updateMutation = useMutation({
    mutationFn: async (data: FollowUpData) => {
      const res = await apiRequest("PATCH", `/api/admin/contacts/${contact.id}`, {
        ...data,
        followUpDate: data.followUpDate?.toISOString(),
      });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/contacts"] });
      toast({
        title: "Follow-up berhasil",
        description: "Status kontak berhasil diperbarui",
      });
      setOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Gagal update",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FollowUpData) => {
    updateMutation.mutate(data);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "new": return "bg-blue-100 text-blue-800";
      case "contacted": return "bg-yellow-100 text-yellow-800";
      case "in_progress": return "bg-purple-100 text-purple-800";
      case "completed": return "bg-green-100 text-green-800";
      case "cancelled": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "new": return "Baru";
      case "contacted": return "Sudah Dihubungi";
      case "in_progress": return "Sedang Proses";
      case "completed": return "Selesai";
      case "cancelled": return "Dibatalkan";
      default: return status;
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5" />
            Follow Up - {contact.name}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Contact Info Summary */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="font-medium mb-2">Informasi Kontak</h4>
            <div className="text-sm space-y-1">
              <p><span className="font-medium">Email:</span> {contact.email}</p>
              <p><span className="font-medium">Service:</span> {contact.service}</p>
              <p><span className="font-medium">Budget:</span> {contact.budget}</p>
              <p><span className="font-medium">Status:</span> 
                <span className={`ml-2 px-2 py-1 rounded-full text-xs ${getStatusColor(contact.status || "new")}`}>
                  {getStatusLabel(contact.status || "new")}
                </span>
              </p>
            </div>
          </div>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Pilih status" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="new">Baru</SelectItem>
                        <SelectItem value="contacted">Sudah Dihubungi</SelectItem>
                        <SelectItem value="in_progress">Sedang Proses</SelectItem>
                        <SelectItem value="completed">Selesai</SelectItem>
                        <SelectItem value="cancelled">Dibatalkan</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Catatan Follow-up</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Tambahkan catatan progress, komunikasi dengan klien, dll..."
                        className="min-h-[100px]"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="followUpDate"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Tanggal Follow-up Berikutnya</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            className="w-full pl-3 text-left font-normal"
                          >
                            {field.value ? (
                              format(field.value, "dd/MM/yyyy")
                            ) : (
                              <span>Pilih tanggal</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          disabled={(date) =>
                            date < new Date()
                          }
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex gap-2 pt-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setOpen(false)}
                  className="flex-1"
                >
                  Batal
                </Button>
                <Button 
                  type="submit" 
                  disabled={updateMutation.isPending}
                  className="flex-1"
                >
                  {updateMutation.isPending ? "Menyimpan..." : "Simpan Follow-up"}
                </Button>
              </div>
            </form>
          </Form>
        </div>
      </DialogContent>
    </Dialog>
  );
}