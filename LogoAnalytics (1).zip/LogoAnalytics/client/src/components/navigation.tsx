import { useState } from "react";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import lagokuLogo from "@assets/lagoku_1751190955742.png";

export default function Navigation() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
      setIsMenuOpen(false);
    }
  };

  return (
    <nav className="fixed w-full top-0 z-50 bg-white/90 backdrop-blur-md border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <img
              src={lagokuLogo}
              alt="Lagoku Logo"
              className="h-8 w-auto mr-2"
            />
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-8">
              <button
                onClick={() => scrollToSection("home")}
                className="text-dark hover:text-primary transition-colors"
              >
                Beranda
              </button>
              <button
                onClick={() => scrollToSection("services")}
                className="text-dark hover:text-primary transition-colors"
              >
                Layanan
              </button>
              <button
                onClick={() => scrollToSection("analysis")}
                className="text-dark hover:text-primary transition-colors"
              >
                Analisa Logo
              </button>
              <button
                onClick={() => scrollToSection("portfolio")}
                className="text-dark hover:text-primary transition-colors"
              >
                Portfolio
              </button>
              <button
                onClick={() => scrollToSection("contact")}
                className="text-dark hover:text-primary transition-colors"
              >
                Kontak
              </button>
            </div>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-dark hover:text-primary"
            >
              {isMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-white border-t border-gray-200">
              <button
                onClick={() => scrollToSection("home")}
                className="block px-3 py-2 text-dark hover:text-primary transition-colors w-full text-left"
              >
                Beranda
              </button>
              <button
                onClick={() => scrollToSection("services")}
                className="block px-3 py-2 text-dark hover:text-primary transition-colors w-full text-left"
              >
                Layanan
              </button>
              <button
                onClick={() => scrollToSection("analysis")}
                className="block px-3 py-2 text-dark hover:text-primary transition-colors w-full text-left"
              >
                Analisa Logo
              </button>
              <button
                onClick={() => scrollToSection("portfolio")}
                className="block px-3 py-2 text-dark hover:text-primary transition-colors w-full text-left"
              >
                Portfolio
              </button>
              <button
                onClick={() => scrollToSection("contact")}
                className="block px-3 py-2 text-dark hover:text-primary transition-colors w-full text-left"
              >
                Kontak
              </button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
