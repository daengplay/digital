import { MessageCircle, Shield } from "lucide-react";
import { FaFacebookF, FaInstagram, FaTiktok } from "react-icons/fa";
import { FaThreads } from "react-icons/fa6";

const footerSections = [
  {
    title: "Layanan",
    links: [
      "Desain Logo Profesional",
      "Brand Guidelines",
      "Pendaftaran Merek",
      "Analisa Logo AI",
      "Redesign Logo",
      "Konsultasi Brand"
    ]
  },
  {
    title: "Perusahaan",
    links: [
      "Tentang Kami",
      "Portfolio",
      "Tim Kreatif",
      "Karir",
      "Blog",
      "Press Kit"
    ]
  },
  {
    title: "Support",
    links: [
      "FAQ",
      "Panduan",
      "Kontak",
      "Syarat & Ketentuan",
      "Kebijakan Privasi",
      "Refund Policy"
    ]
  }
];

export default function Footer() {
  return (
    <footer className="bg-dark text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <h3 className="text-2xl font-bold text-primary mb-4">Lagoku</h3>
            <p className="text-gray-300 mb-6 leading-relaxed">
              Solusi lengkap untuk kebutuhan desain logo profesional, analisa kualitas, dan pendaftaran merek dagang di Indonesia.
            </p>
            <div className="flex space-x-4">
              <button className="text-gray-400 hover:text-primary transition-colors">
                <FaFacebookF className="w-6 h-6" />
              </button>
              <button className="text-gray-400 hover:text-primary transition-colors">
                <FaInstagram className="w-6 h-6" />
              </button>
              <button className="text-gray-400 hover:text-primary transition-colors">
                <FaThreads className="w-6 h-6" />
              </button>
              <button className="text-gray-400 hover:text-primary transition-colors">
                <FaTiktok className="w-6 h-6" />
              </button>
            </div>
          </div>

          {footerSections.map((section, index) => (
            <div key={index}>
              <h4 className="text-lg font-semibold mb-4">{section.title}</h4>
              <ul className="space-y-3 text-gray-300">
                {section.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <button className="hover:text-primary transition-colors text-left">
                      {link}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="border-t border-gray-700 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © 2024 Lagoku. All rights reserved. Made with ❤️ in Indonesia
            </p>
            <div className="flex items-center space-x-6 mt-4 md:mt-0">
              <span className="text-gray-400 text-sm">Trusted by 500+ brands</span>
              <div className="flex items-center space-x-2">
                <Shield className="text-green-500 w-4 h-4" />
                <span className="text-gray-400 text-sm">SSL Secured</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
