import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PaintbrushVertical, Book, Tag, SearchCode, RotateCcw, MessageCircle, Check } from "lucide-react";

const services = [
  {
    icon: PaintbrushVertical,
    title: "Desain Logo Profesional",
    description: "Desain logo custom yang mencerminkan nilai dan kepribadian brand Anda dengan konsep yang unik dan memorable.",
    features: [
      "3-5 Konsep desain awal",
      "Revisi unlimited",
      "File final HD (AI, PNG, JPG)"
    ],
    price: "Mulai dari Rp 500K",
    gradient: "from-blue-50 to-indigo-50",
    border: "border-blue-100",
    iconBg: "bg-primary",
    priceBg: "bg-primary"
  },
  {
    icon: Book,
    title: "Brand Guidelines",
    description: "Panduan lengkap penggunaan brand identity untuk menjaga konsistensi visual di semua platform.",
    features: [
      "Logo usage & variations",
      "Color palette & typography",
      "Application examples"
    ],
    price: "Mulai dari Rp 750K",
    gradient: "from-purple-50 to-pink-50",
    border: "border-purple-100",
    iconBg: "bg-secondary",
    priceBg: "bg-secondary"
  },
  {
    icon: Tag,
    title: "Pendaftaran Merek",
    description: "Bantuan lengkap proses pendaftaran trademark untuk melindungi hak kekayaan intelektual brand Anda.",
    features: [
      "Konsultasi & riset merek",
      "Pengajuan ke Kemenkumham",
      "Follow-up hingga selesai"
    ],
    price: "Mulai dari Rp 2,5 Juta",
    gradient: "from-green-50 to-emerald-50",
    border: "border-green-100",
    iconBg: "bg-green-500",
    priceBg: "bg-green-500"
  },
  {
    icon: SearchCode,
    title: "Analisa Logo AI",
    description: "Evaluasi mendalam kualitas logo Anda dengan teknologi AI dan rekomendasi perbaikan dari expert.",
    features: [
      "Scoring otomatis 10 aspek",
      "Laporan detail PDF",
      "Konsultasi improvement"
    ],
    price: "Rp 150K per analisa",
    gradient: "from-orange-50 to-red-50",
    border: "border-orange-100",
    iconBg: "bg-orange-500",
    priceBg: "bg-orange-500"
  },
  {
    icon: RotateCcw,
    title: "Redesign Logo",
    description: "Refresh dan modernisasi logo existing untuk meningkatkan daya tarik dan relevansi dengan market terkini.",
    features: [
      "Analisa logo existing",
      "3 alternatif redesign",
      "Transisi guide"
    ],
    price: "Mulai dari Rp 400K",
    gradient: "from-teal-50 to-cyan-50",
    border: "border-teal-100",
    iconBg: "bg-teal-500",
    priceBg: "bg-teal-500"
  },
  {
    icon: MessageCircle,
    title: "Konsultasi Brand",
    description: "Sesi konsultasi mendalam untuk mengembangkan strategi brand identity yang tepat sasaran.",
    features: [
      "Brand audit & positioning",
      "Competitor analysis",
      "Strategic roadmap"
    ],
    price: "Rp 300K per sesi",
    gradient: "from-pink-50 to-rose-50",
    border: "border-pink-100",
    iconBg: "bg-accent",
    priceBg: "bg-accent"
  }
];

export default function ServicesSection() {
  const scrollToContact = () => {
    const element = document.getElementById('contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="services" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-dark mb-6">Layanan Profesional Kami</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Dari konsep hingga implementasi, kami menyediakan solusi lengkap untuk identitas visual brand Anda
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <Card key={index} className={`bg-gradient-to-br ${service.gradient} p-8 hover-lift ${service.border}`}>
              <CardContent className="p-0">
                <div className={`w-16 h-16 ${service.iconBg} rounded-2xl flex items-center justify-center mb-6`}>
                  <service.icon className="text-white w-8 h-8" />
                </div>
                <h3 className="text-2xl font-bold text-dark mb-4">{service.title}</h3>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  {service.description}
                </p>
                <ul className="space-y-2 mb-6">
                  {service.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center text-gray-600">
                      <Check className="text-green-500 w-4 h-4 mr-3" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <div className={`text-white font-bold text-xl mb-4 p-3 rounded-lg ${service.priceBg}`}>
                  {service.price}
                </div>
                <Button 
                  onClick={scrollToContact}
                  className={`w-full ${service.iconBg} text-white py-3 rounded-xl font-semibold hover:opacity-90 transition-opacity`}
                >
                  Pesan Sekarang
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
