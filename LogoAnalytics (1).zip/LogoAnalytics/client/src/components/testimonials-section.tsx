import { Card, CardContent } from "@/components/ui/card";
import { Star } from "lucide-react";

const testimonials = [
  {
    name: "Andi Prasetyo",
    role: "CEO TechStart Indonesia",
    content: "Tim Lagoku sangat profesional dan kreatif. Logo yang mereka buat untuk startup saya benar-benar mencerminkan visi perusahaan. Prosesnya juga transparan dan hasil akhirnya melampaui ekspektasi!",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
  },
  {
    name: "Sari Dewi",
    role: "Owner Warung Sari Rasa",
    content: "Pelayanan analisa logo dari Lagoku sangat membantu. Laporan yang detail dan saran perbaikan yang praktis membuat logo restoran kami jauh lebih menarik dan mudah diingat pelanggan.",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
  },
  {
    name: "Rahman Hidayat",
    role: "Founder EduTech Solutions",
    content: "Proses pendaftaran merek dagang melalui Lagoku sangat mudah dan terpercaya. Tim mereka mendampingi dari awal hingga akhir. Sekarang brand saya sudah terlindungi secara legal!",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
  },
];

const stats = [
  { number: "500+", label: "Klien Puas" },
  { number: "150+", label: "Merek Terdaftar" },
  { number: "5", label: "Tahun Pengalaman" },
  { number: "98%", label: "Tingkat Kepuasan" },
];

export default function TestimonialsSection() {
  return (
    <section className="py-20 bg-gradient-to-br from-primary to-secondary">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-6">Apa Kata Klien Kami</h2>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto">
            Kepuasan klien adalah prioritas utama kami. Simak pengalaman mereka bersama Lagoku
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="bg-white/10 backdrop-blur-md glass-effect">
              <CardContent className="p-8">
                <div className="mb-6">
                  <div className="flex text-yellow-400 mb-4">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 fill-current" />
                    ))}
                  </div>
                  <p className="text-white leading-relaxed">
                    "{testimonial.content}"
                  </p>
                </div>
                <div className="flex items-center">
                  <img 
                    src={testimonial.avatar} 
                    alt={testimonial.name}
                    className="w-12 h-12 rounded-full mr-4"
                  />
                  <div>
                    <h4 className="text-white font-semibold">{testimonial.name}</h4>
                    <p className="text-blue-200 text-sm">{testimonial.role}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Trust Indicators */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          {stats.map((stat, index) => (
            <div key={index} className="text-white">
              <div className="text-4xl font-bold text-yellow-400 mb-2">{stat.number}</div>
              <p className="text-blue-100">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
