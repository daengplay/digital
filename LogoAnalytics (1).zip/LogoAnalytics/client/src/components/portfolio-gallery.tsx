import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { PortfolioItem } from "@shared/schema";

const categories = [
  { id: 'all', label: 'Semua' },
  { id: 'tech', label: 'Teknologi' },
  { id: 'food', label: 'Kuliner' },
  { id: 'fashion', label: 'Fashion' },
  { id: 'health', label: 'Kesehatan' },
  { id: 'education', label: 'Edukasi' },
];

const categoryColors: Record<string, string> = {
  tech: 'bg-blue-100 text-blue-800',
  food: 'bg-orange-100 text-orange-800',
  fashion: 'bg-pink-100 text-pink-800',
  health: 'bg-green-100 text-green-800',
  education: 'bg-purple-100 text-purple-800',
};

export default function PortfolioGallery() {
  const [activeFilter, setActiveFilter] = useState('all');

  const { data: portfolioItems = [], isLoading } = useQuery<PortfolioItem[]>({
    queryKey: ['/api/portfolio', activeFilter],
  });

  const handleFilterChange = (categoryId: string) => {
    setActiveFilter(categoryId);
  };

  if (isLoading) {
    return (
      <section id="portfolio" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="animate-pulse">
              <div className="h-8 bg-gray-300 rounded w-64 mx-auto mb-4"></div>
              <div className="h-4 bg-gray-300 rounded w-96 mx-auto"></div>
            </div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="portfolio" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-dark mb-6">Portfolio Pilihan</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Jelajahi koleksi karya terbaik kami dari berbagai industri dan gaya desain
          </p>
        </div>

        {/* Portfolio Filter */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((category) => (
            <Button
              key={category.id}
              onClick={() => handleFilterChange(category.id)}
              variant={activeFilter === category.id ? "default" : "outline"}
              className={`px-6 py-3 rounded-full font-semibold transition-colors ${
                activeFilter === category.id
                  ? 'bg-primary text-white border-primary'
                  : 'border-gray-300 text-gray-600 hover:border-primary hover:text-primary'
              }`}
            >
              {category.label}
            </Button>
          ))}
        </div>

        {/* Portfolio Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {portfolioItems.map((item) => (
            <Card key={item.id} className="bg-white rounded-2xl overflow-hidden shadow-lg hover-lift">
              <img 
                src={item.imageUrl} 
                alt={item.title}
                className="w-full h-48 object-cover"
              />
              <CardContent className="p-6">
                <h3 className="text-xl font-bold text-dark mb-2">{item.title}</h3>
                <p className="text-gray-600 mb-4">{item.description}</p>
                <div className="flex justify-between items-center">
                  <Badge className={categoryColors[item.category] || 'bg-gray-100 text-gray-800'}>
                    {categories.find(cat => cat.id === item.category)?.label || item.category}
                  </Badge>
                  <Button 
                    variant="ghost" 
                    className="text-primary hover:text-blue-700 font-semibold p-0"
                  >
                    Lihat Detail <ArrowRight className="w-4 h-4 ml-1" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button className="bg-primary text-white px-8 py-4 rounded-xl font-semibold hover:bg-blue-700 transition-colors">
            Lihat Semua Portfolio
          </Button>
        </div>
      </div>
    </section>
  );
}
