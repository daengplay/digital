import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  MessageSquare,
  Mail,
  MapPin,
  Search,
  Images,
  MessageCircle,
} from "lucide-react";
import { FaWhatsapp, FaFacebookF, FaInstagram, FaTiktok } from "react-icons/fa";
import { FaThreads } from "react-icons/fa6";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { InsertContactSubmission } from "@shared/schema";

export default function ContactSection() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    service: "",
    budget: "",
    description: "",
    timeline: "",
  });

  const { toast } = useToast();

  // Check URL params for pre-selected service
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const preselectedService = urlParams.get("service");
    if (preselectedService === "expert-consultation") {
      setFormData((prev) => ({
        ...prev,
        service: "expert-consultation",
        description:
          "Saya ingin melakukan konsultasi 1-on-1 dengan expert untuk brand/logo saya.",
      }));
      // Clear the URL parameter after setting
      const newUrl = new URL(window.location.href);
      newUrl.searchParams.delete("service");
      window.history.replaceState({}, "", newUrl);
    }
  }, []);

  const contactMutation = useMutation({
    mutationFn: async (data: InsertContactSubmission) => {
      const response = await apiRequest("POST", "/api/contact", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Pesan Terkirim!",
        description:
          "Terima kasih! Tim kami akan menghubungi Anda dalam 24 jam.",
      });
      setFormData({
        name: "",
        email: "",
        phone: "",
        service: "",
        budget: "",
        description: "",
        timeline: "",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Gagal mengirim pesan. Silakan coba lagi.",
        variant: "destructive",
      });
      console.error("Contact form error:", error);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (
      !formData.name ||
      !formData.email ||
      !formData.service ||
      !formData.description
    ) {
      toast({
        title: "Field Wajib Kosong",
        description: "Silakan lengkapi semua field yang bertanda *",
        variant: "destructive",
      });
      return;
    }
    contactMutation.mutate(formData);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section
      id="contact"
      className="py-20 bg-gradient-to-br from-gray-900 to-blue-900"
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-6">
            Mari Diskusikan Proyek Anda
          </h2>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto">
            Siap mewujudkan brand identity impian Anda? Hubungi kami untuk
            konsultasi gratis dan quote yang sesuai kebutuhan
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <Card className="bg-white/10 backdrop-blur-md glass-effect">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold text-white mb-8">
                Form untuk Konsultasi
              </h3>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-white font-medium mb-2">
                      Nama Lengkap *
                    </label>
                    <Input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) =>
                        handleInputChange("name", e.target.value)
                      }
                      className="bg-white/20 border-white/30 text-white placeholder-blue-200"
                      placeholder="Masukkan nama Anda"
                    />
                  </div>
                  <div>
                    <label className="block text-white font-medium mb-2">
                      Email *
                    </label>
                    <Input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) =>
                        handleInputChange("email", e.target.value)
                      }
                      className="bg-white/20 border-white/30 text-white placeholder-blue-200"
                      placeholder="nama@email.com"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-white font-medium mb-2">
                      No. WhatsApp
                    </label>
                    <Input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) =>
                        handleInputChange("phone", e.target.value)
                      }
                      className="bg-white/20 border-white/30 text-white placeholder-blue-200"
                      placeholder="08xx-xxxx-xxxx"
                    />
                  </div>
                  <div>
                    <label className="block text-white font-medium mb-2">
                      Jenis Layanan *
                    </label>
                    <Select
                      value={formData.service}
                      onValueChange={(value) =>
                        handleInputChange("service", value)
                      }
                    >
                      <SelectTrigger className="bg-white/20 border-white/30 text-white">
                        <SelectValue placeholder="Pilih layanan" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="logo-design">Desain Logo</SelectItem>
                        <SelectItem value="brand-guidelines">
                          Brand Guidelines
                        </SelectItem>
                        <SelectItem value="trademark">
                          Pendaftaran Merek
                        </SelectItem>
                        <SelectItem value="logo-analysis">
                          Analisa Logo
                        </SelectItem>
                        <SelectItem value="redesign">Redesign Logo</SelectItem>
                        <SelectItem value="consultation">
                          Konsultasi Brand
                        </SelectItem>
                        <SelectItem value="expert-consultation">
                          Konsultasi Expert - Rp 300K
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <label className="block text-white font-medium mb-2">
                    Budget Range
                  </label>
                  <Select
                    value={formData.budget}
                    onValueChange={(value) =>
                      handleInputChange("budget", value)
                    }
                  >
                    <SelectTrigger className="bg-white/20 border-white/30 text-white">
                      <SelectValue placeholder="Pilih range budget" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="under-500k">
                        Di bawah Rp 500K
                      </SelectItem>
                      <SelectItem value="500k-1m">Rp 500K - 1 Juta</SelectItem>
                      <SelectItem value="1m-2m">Rp 1 - 2 Juta</SelectItem>
                      <SelectItem value="2m-5m">Rp 2 - 5 Juta</SelectItem>
                      <SelectItem value="above-5m">
                        Di atas Rp 5 Juta
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-white font-medium mb-2">
                    Deskripsi Proyek *
                  </label>
                  <Textarea
                    required
                    rows={4}
                    value={formData.description}
                    onChange={(e) =>
                      handleInputChange("description", e.target.value)
                    }
                    className="bg-white/20 border-white/30 text-white placeholder-blue-200 resize-none"
                    placeholder="Ceritakan tentang brand dan kebutuhan desain Anda..."
                  />
                </div>

                <div>
                  <label className="block text-white font-medium mb-2">
                    Timeline Proyek
                  </label>
                  <Select
                    value={formData.timeline}
                    onValueChange={(value) =>
                      handleInputChange("timeline", value)
                    }
                  >
                    <SelectTrigger className="bg-white/20 border-white/30 text-white">
                      <SelectValue placeholder="Pilih timeline" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="urgent">Urgent (1-3 hari)</SelectItem>
                      <SelectItem value="normal">
                        Normal (1-2 minggu)
                      </SelectItem>
                      <SelectItem value="flexible">
                        Fleksibel (1 bulan+)
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button
                  type="submit"
                  disabled={contactMutation.isPending}
                  className="w-full bg-primary text-white px-8 py-4 h-auto rounded-xl font-semibold hover:bg-blue-700 transition-colors"
                >
                  <MessageSquare className="w-4 h-4 mr-2" />
                  {contactMutation.isPending
                    ? "Mengirim..."
                    : "Kirim Pesan & Dapatkan Quote"}
                </Button>

                <p className="text-blue-200 text-sm text-center">
                  * Field yang wajib diisi. Kami akan merespon dalam 24 jam
                </p>
              </form>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <div className="space-y-8">
            <Card className="bg-white/10 backdrop-blur-md glass-effect">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold text-white mb-6">
                  Kontak Langsung
                </h3>

                <div className="space-y-6">
                  <div className="flex items-center">
                    <div className="w-14 h-14 bg-primary rounded-2xl flex items-center justify-center mr-4">
                      <FaWhatsapp className="text-white text-xl" />
                    </div>
                    <div>
                      <h4 className="text-white font-semibold">WhatsApp</h4>
                      <p className="text-blue-200">+6285398932001</p>
                      <p className="text-blue-200 text-sm">
                        Fast response 24/7
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center">
                    <div className="w-14 h-14 bg-secondary rounded-2xl flex items-center justify-center mr-4">
                      <Mail className="text-white text-xl" />
                    </div>
                    <div>
                      <h4 className="text-white font-semibold">Email</h4>
                      <p className="text-blue-200">makassarlagoku@gmail.com</p>
                      <p className="text-blue-200 text-sm">
                        Response dalam 2-4 jam
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center">
                    <div className="w-14 h-14 bg-green-500 rounded-2xl flex items-center justify-center mr-4">
                      <MapPin className="text-white text-xl" />
                    </div>
                    <div>
                      <h4 className="text-white font-semibold">Kantor</h4>
                      <p className="text-blue-200">
                        Makassar, Sulawesi Selatan
                      </p>
                      <p className="text-blue-200 text-sm">
                        Meet by appointment
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Links */}
            <Card className="bg-white/10 backdrop-blur-md glass-effect">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold text-white mb-6">
                  Quick Actions
                </h3>

                <div className="space-y-4">
                  <Button
                    onClick={() => scrollToSection("analysis")}
                    className="w-full bg-orange-500 text-white px-6 py-4 h-auto rounded-xl font-semibold hover:bg-orange-600 transition-colors"
                  >
                    <Search className="w-4 h-4 mr-2" />
                    Analisa Logo Gratis
                  </Button>
                  <Button
                    onClick={() => scrollToSection("portfolio")}
                    className="w-full bg-purple-500 text-white px-6 py-4 h-auto rounded-xl font-semibold hover:bg-purple-600 transition-colors"
                  >
                    <Images className="w-4 h-4 mr-2" />
                    Lihat Portfolio
                  </Button>
                  <Button
                    asChild
                    className="w-full bg-green-500 text-white px-6 py-4 h-auto rounded-xl font-semibold hover:bg-green-600 transition-colors"
                  >
                    <a
                      href="https://wa.me/6285398932001"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <FaWhatsapp className="w-4 h-4 mr-2" />
                      Chat WhatsApp
                    </a>
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Social Media */}
            <Card className="bg-white/10 backdrop-blur-md glass-effect">
              <CardContent className="p-8">
                <h3 className="text-xl font-bold text-white mb-6">
                  Follow Kami
                </h3>

                <div className="flex space-x-4">
                  <Button size="icon" className="bg-blue-600 hover:bg-blue-700">
                    <FaFacebookF className="w-4 h-4" />
                  </Button>
                  <Button size="icon" className="bg-pink-600 hover:bg-pink-700">
                    <FaInstagram className="w-4 h-4" />
                  </Button>
                  <Button size="icon" className="bg-gray-800 hover:bg-gray-900">
                    <FaThreads className="w-4 h-4" />
                  </Button>
                  <Button size="icon" className="bg-black hover:bg-gray-800">
                    <FaTiktok className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
